package id.rayhan.deathdimension;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.*;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;

import java.util.*;

public final class DeathDimension extends JavaPlugin implements Listener, CommandExecutor {
    private final Map<UUID, Long> punishments = new HashMap<>();
    private final LegacyComponentSerializer legacy = LegacyComponentSerializer.legacyAmpersand();
    private BukkitTask ticker;
    private final Map<UUID, BukkitTask> animationTasks = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadPunishments();
        createVoidWorld();
        Objects.requireNonNull(getCommand("deathdimension")).setExecutor(this);
        getServer().getPluginManager().registerEvents(this, this);
        ticker = getServer().getScheduler().runTaskTimer(this, this::tickPunishments, 20L, 20L);
        getLogger().info("DeathDimension V2 enabled.");
    }

    @Override
    public void onDisable() {
        if (ticker != null) ticker.cancel();
        for (BukkitTask task : animationTasks.values()) task.cancel();
        animationTasks.clear();
        savePunishments();
    }

    private void createVoidWorld() {
        String name = getConfig().getString("void.world", "death_void");
        World world = Bukkit.getWorld(name);
        if (world == null) {
            ChunkGenerator emptyGenerator = new ChunkGenerator() {
                @Override
                public ChunkData generateChunkData(World world, Random random, int x, int z, BiomeGrid biome) {
                    return createChunkData(world);
                }
            };
            world = new WorldCreator(name).environment(World.Environment.NORMAL).generator(emptyGenerator).createWorld();
        }
        if (world == null) {
            getLogger().severe("Gagal membuat world void: " + name);
            return;
        }
        world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
        world.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        world.setTime(18000);
        world.setStorm(false);
        world.setThundering(false);
        Location center = voidLocation();
        int radius = Math.max(1, getConfig().getInt("void.platform-radius", 3));
        Material platform;
        try {
            platform = Material.valueOf(getConfig().getString("void.platform-block", "BLACKSTONE").toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            platform = Material.BLACKSTONE;
        }
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                world.getBlockAt(center.getBlockX() + x, center.getBlockY() - 1, center.getBlockZ() + z).setType(platform, false);
            }
        }
        world.setSpawnLocation(center);
    }

    private Location voidLocation() {
        World world = Bukkit.getWorld(getConfig().getString("void.world", "death_void"));
        if (world == null) return Bukkit.getWorlds().get(0).getSpawnLocation();
        return new Location(world,
                getConfig().getDouble("void.x", 0.5),
                getConfig().getDouble("void.y", 80.0),
                getConfig().getDouble("void.z", 0.5),
                0f, 0f);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        long expiry = System.currentTimeMillis() + getConfig().getLong("punishment-seconds", 10800) * 1000L;
        punishments.put(player.getUniqueId(), expiry);
        savePunishments();

        if (getConfig().getBoolean("cinematic.auto-respawn", true)) {
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (player.isOnline() && player.isDead()) {
                    try {
                        player.spigot().respawn();
                    } catch (Throwable ex) {
                        getLogger().warning("Auto-respawn tidak didukung oleh server ini; pemain perlu menekan Respawn.");
                    }
                }
            }, 2L);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onRespawn(PlayerRespawnEvent event) {
        if (!punishments.containsKey(event.getPlayer().getUniqueId())) return;
        event.setRespawnLocation(voidLocation());
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!player.isOnline()) return;
            player.teleport(voidLocation());
            playDeathCinematic(player);
        }, 2L);
    }

    private void playDeathCinematic(Player player) {
        int blind = getConfig().getInt("cinematic.blindness-ticks", 50);
        int dark = getConfig().getInt("cinematic.darkness-ticks", 50);
        if (blind > 0) player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, blind, 0, false, false, false));
        if (dark > 0) player.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, dark, 0, false, false, false));

        String title = getConfig().getString("cinematic.title", "&4&lKAMU MATI");
        String subtitle = getConfig().getString("cinematic.subtitle", "&7Jiwamu telah meninggalkan dunia ini...");
        player.showTitle(net.kyori.adventure.title.Title.title(
                legacy.deserialize(title),
                legacy.deserialize(subtitle),
                net.kyori.adventure.title.Title.Times.times(
                        java.time.Duration.ofMillis(getConfig().getLong("cinematic.title-fade-in", 20) * 50),
                        java.time.Duration.ofMillis(getConfig().getLong("cinematic.title-stay", 50) * 50),
                        java.time.Duration.ofMillis(getConfig().getLong("cinematic.title-fade-out", 20) * 50)
                )
        ));

        String soundName = getConfig().getString("cinematic.sound", "ENTITY_WITHER_DEATH");
        try {
            player.playSound(player.getLocation(), Sound.valueOf(soundName.toUpperCase(Locale.ROOT)), 0.8f, 0.65f);
        } catch (IllegalArgumentException ignored) {
            player.playSound(player.getLocation(), Sound.ENTITY_WITHER_DEATH, 0.8f, 0.65f);
        }
        player.sendMessage(legacy.deserialize("&8Sebuah kekuatan menarik jiwamu ke dimensi kehampaan..."));
        spawnSoulParticles(player);
        startDeathAnimation(player);
    }


    /**
     * Cinematic visual sequence: the player briefly takes a collapsed pose,
     * then rises slowly while soul particles orbit around them. Lightning is
     * visual-only and cannot damage the player or nearby builds.
     */
    private void startDeathAnimation(Player player) {
        UUID id = player.getUniqueId();
        BukkitTask old = animationTasks.remove(id);
        if (old != null) old.cancel();

        int totalTicks = Math.max(20, getConfig().getInt("cinematic.animation-duration-ticks", 80));
        int riseDelay = Math.max(0, getConfig().getInt("cinematic.animation-rise-delay-ticks", 20));
        int particlePeriod = Math.max(1, getConfig().getInt("cinematic.animation-particle-period-ticks", 2));
        boolean lightning = getConfig().getBoolean("cinematic.visual-lightning", true);

        player.setSwimming(true); // creates a brief collapsed / unconscious-looking pose
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(this, new Runnable() {
            int tick = 0;

            @Override
            public void run() {
                if (!player.isOnline() || !player.isValid() || !punishments.containsKey(id)) {
                    finish();
                    return;
                }

                Location base = player.getLocation();
                if (tick >= riseDelay) {
                    // Gentle lift, not a damaging teleport or a real lightning strike.
                    if (tick == riseDelay) {
                        player.setSwimming(false);
                        player.addPotionEffect(new PotionEffect(
                                PotionEffectType.LEVITATION,
                                Math.max(1, totalTicks - riseDelay),
                                0, false, false, false
                        ));
                    }
                    if (tick % 10 == 0) {
                        base.getWorld().spawnParticle(Particle.CLOUD,
                                base.clone().add(0, 0.15, 0), 5, 0.35, 0.08, 0.35, 0.01);
                    }
                }

                if (tick % particlePeriod == 0) {
                    double angle = tick * 0.22;
                    for (int i = 0; i < 8; i++) {
                        double a = angle + (Math.PI * 2.0 * i / 8.0);
                        double x = Math.cos(a) * 0.85;
                        double z = Math.sin(a) * 0.85;
                        Location point = base.clone().add(x, 0.25 + (i % 3) * 0.45, z);
                        base.getWorld().spawnParticle(Particle.SOUL, point, 1, 0, 0, 0, 0);
                        base.getWorld().spawnParticle(Particle.SCULK_SOUL,
                                point.clone().add(0, 0.15, 0), 1, 0, 0, 0, 0);
                    }
                    base.getWorld().spawnParticle(Particle.REVERSE_PORTAL,
                            base.clone().add(0, 1.0, 0), 3, 0.35, 0.55, 0.35, 0.02);
                }

                if (lightning && (tick == 8 || tick == 28 || tick == 48)) {
                    base.getWorld().strikeLightningEffect(base.clone().add(0, 0, 0));
                }

                tick++;
                if (tick >= totalTicks) finish();
            }

            private void finish() {
                player.setSwimming(false);
                player.removePotionEffect(PotionEffectType.LEVITATION);
                BukkitTask current = animationTasks.remove(id);
                if (current != null) current.cancel();
            }
        }, 1L, 1L);
        animationTasks.put(id, task);
    }

    private void spawnSoulParticles(Player player) {
        if (!getConfig().getBoolean("cinematic.particles", true)) return;
        Location loc = player.getLocation().add(0, 1, 0);
        player.getWorld().spawnParticle(Particle.SOUL, loc, 45, 0.8, 1.0, 0.8, 0.04);
        player.getWorld().spawnParticle(Particle.SCULK_SOUL, loc, 20, 0.5, 0.8, 0.5, 0.02);
        player.getWorld().spawnParticle(Particle.SMOKE, loc, 25, 0.6, 0.8, 0.6, 0.02);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        Long expiry = punishments.get(player.getUniqueId());
        if (expiry != null && expiry > System.currentTimeMillis()) {
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (player.isOnline()) {
                    player.teleport(voidLocation());
                    player.sendMessage(legacy.deserialize("&8Kamu masih berada dalam hukuman Death Dimension."));
                }
            }, 10L);
        } else if (expiry != null) {
            punishments.remove(player.getUniqueId());
            savePunishments();
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        // Waktu hukuman tetap berjalan saat pemain offline.
        BukkitTask task = animationTasks.remove(event.getPlayer().getUniqueId());
        if (task != null) task.cancel();
        event.getPlayer().setSwimming(false);
        event.getPlayer().removePotionEffect(PotionEffectType.LEVITATION);
    }

    private void tickPunishments() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<UUID, Long>> iterator = punishments.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, Long> entry = iterator.next();
            Player player = Bukkit.getPlayer(entry.getKey());
            long remaining = entry.getValue() - now;
            if (remaining <= 0) {
                iterator.remove();
                BukkitTask animation = animationTasks.remove(entry.getKey());
                if (animation != null) animation.cancel();
                if (player != null && player.isOnline()) {
                    player.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
                    player.clearTitle();
                    player.removePotionEffect(PotionEffectType.BLINDNESS);
                    player.removePotionEffect(PotionEffectType.DARKNESS);
                    player.sendMessage(legacy.deserialize("&aWaktumu di Death Dimension telah berakhir."));
                    player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.8f, 1.0f);
                }
            } else if (player != null && player.isOnline()) {
                String actionbar = getConfig().getString("cinematic.actionbar", "&8Kembali ke dunia dalam &c%time%");
                player.sendActionBar(legacy.deserialize(actionbar.replace("%time%", formatTime(remaining))));
                if (getConfig().getBoolean("cinematic.particles", true) && Math.random() < 0.25) {
                    player.getWorld().spawnParticle(Particle.SOUL, player.getLocation().add(0, 1, 0), 3, 0.35, 0.5, 0.35, 0.01);
                }
            }
        }
        savePunishments();
    }

    private String formatTime(long millis) {
        long seconds = Math.max(0, millis / 1000);
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;
        return String.format(Locale.ROOT, "%02d:%02d:%02d", hours, minutes, secs);
    }

    private void loadPunishments() {
        punishments.clear();
        var section = getConfig().getConfigurationSection("punishments");
        if (section == null) return;
        for (String key : section.getKeys(false)) {
            try {
                punishments.put(UUID.fromString(key), section.getLong(key));
            } catch (IllegalArgumentException ignored) {
                getLogger().warning("UUID hukuman tidak valid: " + key);
            }
        }
    }

    private void savePunishments() {
        getConfig().set("punishments", null);
        for (Map.Entry<UUID, Long> entry : punishments.entrySet()) {
            getConfig().set("punishments." + entry.getKey(), entry.getValue());
        }
        saveConfig();
    }

    private String color(String text) {
        return text == null ? "" : text.replace('&', '§');
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("deathdimension.admin")) {
            sender.sendMessage(legacy.deserialize(getConfig().getString("messages.no-permission", "&cKamu tidak punya izin.")));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(legacy.deserialize(getConfig().getString("messages.usage")));
            return true;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            sender.sendMessage(legacy.deserialize(getConfig().getString("messages.reloaded")));
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(legacy.deserialize(getConfig().getString("messages.usage")));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(Component.text("Pemain tidak ditemukan.", NamedTextColor.RED));
            return true;
        }
        if (args[0].equalsIgnoreCase("release")) {
            BukkitTask animation = animationTasks.remove(target.getUniqueId());
            if (animation != null) animation.cancel();
            target.setSwimming(false);
            target.removePotionEffect(PotionEffectType.LEVITATION);
            if (punishments.remove(target.getUniqueId()) == null) {
                sender.sendMessage(legacy.deserialize(getConfig().getString("messages.no-punishment")));
                return true;
            }
            savePunishments();
            target.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
            target.clearTitle();
            target.removePotionEffect(PotionEffectType.BLINDNESS);
            target.removePotionEffect(PotionEffectType.DARKNESS);
            target.sendMessage(legacy.deserialize(getConfig().getString("messages.released")));
            sender.sendMessage(legacy.deserialize(getConfig().getString("messages.released")));
            return true;
        }
        if (args[0].equalsIgnoreCase("send")) {
            punishments.put(target.getUniqueId(), System.currentTimeMillis() + getConfig().getLong("punishment-seconds", 10800) * 1000L);
            savePunishments();
            target.teleport(voidLocation());
            playDeathCinematic(target);
            sender.sendMessage(legacy.deserialize(getConfig().getString("messages.sent")));
            return true;
        }
        sender.sendMessage(legacy.deserialize(getConfig().getString("messages.usage")));
        return true;
    }
}
