DeathDimension V2 - Paper 1.21.11

Fitur:
- Hukuman default 3 jam (10800 detik)
- World kosong death_void dengan platform kecil
- Auto-respawn (bergantung dukungan API server)
- Title KAMU MATI, subtitle, blindness/darkness, suara, partikel jiwa
- Animasi pingsan singkat, melayang perlahan, partikel jiwa berputar, dan petir visual (tanpa damage)
- Actionbar countdown
- /dd reload
- /dd send <player>
- /dd release <player>

Build:
1. Ekstrak ZIP ini.
2. Jalankan: mvn clean package
3. Ambil JAR dari folder target.

Penting:
Plugin Paper tidak dapat menghapus atau mengganti seluruh layar kematian client secara total.
Auto-respawn memakai Player.Spigot#respawn(); jika fork server tidak mendukungnya, pemain
mungkin tetap harus menekan tombol Respawn. Animasi title/effect muncul setelah respawn. Animasi melayang menggunakan efek Levitation sementara; pose pingsan menggunakan pose swimming, sehingga tampilan dapat sedikit berbeda antar-client.
Uji dahulu pada server salinan/backup sebelum dipasang di server utama.
